<?php

//access submissions directory and prepare filename
$directory = "/home/vgerde/tmp/submissions/";
$file = $directory . basename($_FILES["fileToUpload"]["name"]);

//sanitize user input to prevent command injection
$fileNamePreSanitization = $_FILES["fileToUpload"]["name"];
$fileName = preg_replace('/[^0-9A-Za-z_.]/', '', $fileNamePreSanitization);

//check size
if($_FILES["fileToUpload"]["size"] > 524288000)
{
	echo "The file is too large must be under 500MB";
	die;
}

//check if its a proper excel spreadsheet
if(end((explode(".", $fileName))) != "xlsx")
{
	echo "Wrong file type, must be an excel file: \"example.xlsx\"";
	die;
}

//if all clear, upload and run script
if(move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $file))
{	
	#check to see if final submission or not
	if(isset($_POST["output"]))
	{
		$command = "sh /home/vgerde/tmp/start.sh $fileName true 2>&1"; 
	}
	else
	{
		$command = "sh /home/vgerde/tmp/start.sh $fileName false 2>&1";
	}

	exec($command);
	header("Location: https://cs.furman.edu/~vgerde/graded/$fileName.html");
}
else
{
	echo "The file failed to upload";
}
?>
