#/bin/sh

#if no arguments given, stop, otherwise continue
if [ "$#" -eq 0 ]; then
	exit
else
	#had to do this to fix a bug
	export LC_ALL=en_US.utf-8
	export LANG=en_US.utf-8

	#enable python virtual environment so apache can run the python
	source /home/vgerde/tmp/venv/bin/activate

	#empty old graded sheets
	rm ../www/graded/*

	#enter writable directory in vgerde
	cd /home/vgerde/tmp/
	key=$(python /home/vgerde/tmp/getKeyFromSpreadsheet.py $1)

	#if no key detected, stop
	if [ "$key" == "KeyNotFound" ]; then
		exit
	fi
	
	#run pysheetgrader on given file, then disable python virtual environment
	$(python -m pysheetgrader keys/$key submissions/$1 --html-report-output ../www/graded/$1.html)
	if [ $2 = "true" ]; then
		cp ../www/graded/$1.html graded
	fi
 
	deactivate

fi
