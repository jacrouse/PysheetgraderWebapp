import sys
import openpyxl


def find_key_in_xlsx(file_path, key_cell):
    try:
        workbook = openpyxl.load_workbook(file_path)
        worksheet = workbook.active
        key_value = worksheet[key_cell].value
        
        if key_value:
            return key_value
        else:
            return "KeyNotFound"

    except Exception as e:
        return f"KeyNotFound"


def main():
	if(len(sys.argv) < 2):
		exit()
	
	file_path = "submissions/"
	file_path += sys.argv[1]

	key_cell = "B2" 

	key = find_key_in_xlsx(file_path, key_cell)
	print(key)


if __name__ == "__main__":
	main()
